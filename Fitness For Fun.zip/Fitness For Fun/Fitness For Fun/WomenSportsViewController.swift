//
//  WomenSportsViewController.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/29/22.
//

import UIKit

class WomenSportsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btnBasketBallClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-basketball"
         openUrl(url: url)
    }
    
    
    @IBAction func btnCrossCountryClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-cross-country"
         openUrl(url: url)
    }
    
    
    @IBAction func btnGolfClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-golf"
         openUrl(url: url)
    }
    
    
    @IBAction func btnSoccerClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-soccer"
         openUrl(url: url)
    }
    
    
    @IBAction func btnTrackFieldClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-track-and-field"
         openUrl(url: url)
    }
    
    @IBAction func btnTennisClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-tennis"
         openUrl(url: url)
    }
    
    
    @IBAction func btnVolleyBallClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-volleyball"
         openUrl(url: url)
    }
    
    @IBAction func btnBeachVBClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/womens-beach-volleyball"
         openUrl(url: url)
        
    }
    
    
    @IBAction func btnBAckClicked(_ sender: Any) {
        self.dismiss(animated: false)
        
        
    }
    
    func openUrl(url:String) {
        if let url = URL(string: url), UIApplication.shared.canOpenURL(url) {
           if #available(iOS 10.0, *) {
              UIApplication.shared.open(url, options: [:], completionHandler: nil)
           } else {
              UIApplication.shared.openURL(url)
           }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
