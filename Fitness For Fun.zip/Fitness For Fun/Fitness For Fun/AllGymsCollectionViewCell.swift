//
//  AllGymsCollectionViewCell.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/29/22.
//

import UIKit

class AllGymsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var txtViewAllGyms: UITextView!
    @IBOutlet weak var vwBgCell: UIView!
    @IBOutlet weak var lblGymName: UILabel!
    
}
