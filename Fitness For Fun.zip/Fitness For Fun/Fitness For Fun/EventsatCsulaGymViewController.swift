//
//  EventsatCsulaGymViewController.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/29/22.
//

import UIKit

class EventsatCsulaGymViewController: UIViewController {
    
    
    
    @IBAction func btnUpcomingEventsclicked(_ sender: Any) {
        let url = "https://www.instagram.com/calstatela_recreation/"
         openUrl(url: url)
        
    }
    
    
    @IBAction func btnRecreationExercisescheduleClicked(_ sender: Any) {
        
        let url = "https://www.calstatelausu.org/Recreation/Schedule"
         openUrl(url: url)
    }
    
    @IBAction func btnXtremeFitnessScheduleClicked(_ sender: Any) {
        let url = "https://www.calstatelausu.org/Recreation/fitnesscenter"
         openUrl(url: url)
        
    }
    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: false)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func openUrl(url:String) {
        if let url = URL(string: url), UIApplication.shared.canOpenURL(url) {
           if #available(iOS 10.0, *) {
              UIApplication.shared.open(url, options: [:], completionHandler: nil)
           } else {
              UIApplication.shared.openURL(url)
           }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
