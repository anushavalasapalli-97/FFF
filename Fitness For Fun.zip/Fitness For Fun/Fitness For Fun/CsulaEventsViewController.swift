//
//  CsulaEventsViewController.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/29/22.
//

import UIKit

class CsulaEventsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnClickedUpcomingEvents(_ sender: Any) {
        let url = "https://www.calstatela.edu/univ/calendar/index.htm"
         openUrl(url: url)
    }
    
    
    @IBAction func btnClickedStudentUnion(_ sender: Any) {
        let url = "https://www.calstatlausu.org/"
         openUrl(url: url)
    }
    
    
    
    @IBAction func btnClickedRecreationActivities(_ sender: Any) {
        let url = "https://www.instagram.com/calstatela_recreation/?igshid=YmMyMTA2M2Y="
         openUrl(url: url)
    }
    
    
    @IBAction func btnClickedStudenInvolvement(_ sender: Any) {
        let url = "https://www.calstatela.edu/studentservices/center-student-involvement"
         openUrl(url: url)
    }
    
    
    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: false)
        
    }
    
    
    func openUrl(url:String) {
        if let url = URL(string: url), UIApplication.shared.canOpenURL(url) {
           if #available(iOS 10.0, *) {
              UIApplication.shared.open(url, options: [:], completionHandler: nil)
           } else {
              UIApplication.shared.openURL(url)
           }
        }
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
