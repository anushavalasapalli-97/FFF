//
//  HomeWorkoutsViewController.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/29/22.
//

import UIKit

class HomeWorkoutsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btnYogaClicked(_ sender: Any) {
      //
        
        let url = "https://www.youtube.com/playlist?list=PL15ULpah8MpUhpiCZKm6HcMp1JEcBJriZ"
         openUrl(url: url)
    }
    
    @IBAction func btnPilatesClicked(_ sender: Any) {
        
        let url = "https://www.youtube.com/playlist?list=PL15ULpah8MpWR3Mo9hmdBuInMgQTIgaVU"
         openUrl(url: url)
    }
    
    
    
    @IBAction func btnZumbaClicked(_ sender: Any) {
        
        let url = "https://www.youtube.com/playlist?list=PL15ULpah8MpUVL_cVoUF2jE59d8UPOMAn"
         openUrl(url: url)
    }
    
    @IBAction func btnMenWorkoutsClicked(_ sender: Any) {
        
        let url = "https://www.youtube.com/playlist?list=PL15ULpah8MpVGPltXxSqhpL3ycnNOseW8"
         openUrl(url: url)
        
    }
    @IBAction func btnDanceClicked(_ sender: Any) {
        
        let url = "https://www.youtube.com/playlist?list=PL15ULpah8MpVIRVDtE6QvCvgc8-ZlekZf"
         openUrl(url: url)
        
    }
    
    @IBAction func btnWomenWorkoutsClicked(_ sender: Any) {
    
        let url = "https://www.youtube.com/playlist?list=PL15ULpah8MpVWbHeMoJaEua7_cYtKVhEq"
         openUrl(url: url)
    }
    
    @IBAction func btnFitonAppClicked(_ sender: Any) {
        //"https://fitonapp.com/"
        let url = "https://fitonapp.com/"
         openUrl(url: url)
    }
    
    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: false)
    }
    func openUrl(url:String) {
        if let url = URL(string: url), UIApplication.shared.canOpenURL(url) {
           if #available(iOS 10.0, *) {
              UIApplication.shared.open(url, options: [:], completionHandler: nil)
           } else {
              UIApplication.shared.openURL(url)
           }
        }
    }
    
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
