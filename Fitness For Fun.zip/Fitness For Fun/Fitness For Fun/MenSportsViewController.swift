//
//  MenSportsViewController.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/29/22.
//

import UIKit

class MenSportsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnBaseballClicked(_ sender: Any) {
       let url = "https://lagoldeneagles.com/sports/baseball"
        openUrl(url: url)
    }
    
    @IBAction func btnBasketballClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/mens-basketball"
         openUrl(url: url)
    }
    
    
    @IBAction func btnCrossCountryClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/mens-cross-country"
         openUrl(url: url)
    }
    
    
    @IBAction func btnSoccerClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/mens-soccer"
         openUrl(url: url)
    }
    
    @IBAction func btnTrackFieldClicked(_ sender: Any) {
        let url = "https://lagoldeneagles.com/sports/mens-track-and-field"
         openUrl(url: url)
    }
    
    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: false)
    }
    func openUrl(url:String) {
        if let url = URL(string: url), UIApplication.shared.canOpenURL(url) {
           if #available(iOS 10.0, *) {
              UIApplication.shared.open(url, options: [:], completionHandler: nil)
           } else {
              UIApplication.shared.openURL(url)
           }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
