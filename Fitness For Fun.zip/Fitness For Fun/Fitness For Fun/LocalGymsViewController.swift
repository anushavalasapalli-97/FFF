//
//  LocalGymsViewController.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/29/22.
//

import UIKit

class LocalGymsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITextViewDelegate {
    @IBOutlet weak var collectionViewGyms: UICollectionView!
    let reuseIdentifier = "allgyms" // also enter this string as the cell identifier in the storyboard
       var items = [" distance from CSULA \n 1.6 miles \n Hours \n 5am - 10 pm weekdays \n  8am - 5 pm weekdays \n PRICE TIER 1 \n $34.99/month with $99 initiation fee \n PRICE TIER 2 \n $44.99/month with 0 initiation fee \n Location: \n 920 S Fremont Ave Alhambra, CA 91803 \n", "DISTANCE FROM CSULA \n 1.8 miles \n HOURS \n 5am - 12am everyday \n PRICE TIER 1 \n $59/month \n PRICE TIER 2 \n $15 day pass \n Location: 690 Date Ave Alhambra, CA91803 ", "DISTANCE FROM CSULA \n 3.0 miles \n Hours \n 24/7 \n PRICE TIER 1 \n Platinum - $44.99/month or $419.88/year \n PRICE TIER 2 \n Gold - $29.99/month or $299.88/year \n Location: 500N Atlantic Blvd ste A-102-1 Monetery Park, CA 91754", "DISTANCE FROM CSULA \n 3.1 miles \nHOURS \next5am -12am everyday \n PRICE TIER 1 \n $100/month - student discounts are avilable \n PRICE TIER 2 \n 1 day guest pass $20 / 5day $50 \n Location: 646 Gibbons St Los Angles, CA 90031", "DISTANCE FROM CSULA \n 4.2 miles \n HOURS 24/7 \n PRICE TIER 1 \n PF Black Card - $22.99/month \n PRICE TIER 2 \n Classic - $10/month \n Location: 610 Valley Blvd Alhambra, CA 91801", "DISTANCE FROM CSULA \n 6.7 miles \n HOURS \n 24/7 \n PRICE TIER 1 \n 24 Month Plan - $59.99/month \n PRICE TIER 2 \n 12 Month Plan - $64.99/month\n Location: 600 E ColoradoBlvd Suite 140 Pasadena, CA 91101 "]
    
       var gyms = ["LA FITNESS", "MISSION FITNESS CENTER", "24 HOUR FITNESS (SPORT", "BARBELL BRIDGE GYM", "PLANET FITNESS", "ANYTIME FITNESS PASADENA"]
    let spacing : CGFloat = 10.0

    @IBOutlet weak var veBgCell: UIView!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionViewGyms.delegate = self
        collectionViewGyms.dataSource = self
        
        
        
     
        }
    
    @IBAction func btnClickHereToSeeWhatsHappenInside(_ sender: Any) {
        
        let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EventsatCsulaGymViewController")
        controller.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(controller, animated: true, completion: nil)
     
        
    }
    
 
    
    
       // MARK: - UICollectionViewDataSource protocol
       
       // tell the collection view how many cells to make
       func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
           return items.count
           
       }
       
       // make a cell for each cell index path
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           
           // get a reference to our storyboard cell
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! AllGymsCollectionViewCell
           cell.txtViewAllGyms.delegate = self
           let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: cell.lblGymName.frame.size.height))
           cell.lblGymName .addSubview(paddingView)
           // Use the outlet in our custom class to get a reference to the UILabel in the cell
           cell.txtViewAllGyms.text = self.items[indexPath.row] // The row value is the same as the index of the desired text within the array.
           cell.vwBgCell.layer.cornerRadius = 5
           cell.vwBgCell.layer.borderWidth = 5
           cell.vwBgCell.layer.borderColor = UIColor.black.cgColor
           cell.lblGymName.text = gyms[indexPath.row]
           cell.txtViewAllGyms.isEditable = false

         


           
           return cell
       }
    
       
       // MARK: - UICollectionViewDelegate protocol
       
//       func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//           // handle tap events
//           print("You selected cell #\(indexPath.item)!")
//       }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)//here your custom value for spacing
    }
 

    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: false)
    }
    

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let lay = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 3 - lay.minimumInteritemSpacing
      
        return CGSize(width:180, height:200)
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


