//
//  SignupViewController.swift
//  Fitness For Fun
//
//  Created by AnushaValasapalli on 4/28/22.
//

import UIKit

class SignupViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtFieldStudent: UITextField!
    
    @IBOutlet weak var txtFieldEmail: UITextField!
    
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    @IBOutlet weak var txtFieldDateOfBirth: UITextField!
    var datePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      showDatePicker()
    }
    
    
    func showDatePicker(){
       //Formate Date
       datePicker.datePickerMode = .date
        datePicker.backgroundColor = UIColor(red: 255/255, green: 235/255, blue: 225/255, alpha: 1.0)

      //ToolBar
      let toolbar = UIToolbar();
      toolbar.sizeToFit()
      let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
      let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
      let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));

      toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)

      txtFieldDateOfBirth.inputAccessoryView = toolbar
      txtFieldDateOfBirth.inputView = datePicker

    }

     @objc func donedatePicker(){

      let formatter = DateFormatter()
      formatter.dateFormat = "dd/MM/yyyy"
     txtFieldDateOfBirth.text = formatter.string(from: datePicker.date)
      self.view.endEditing(true)
    }
    @objc func cancelDatePicker(){
       self.view.endEditing(true)
     }
    
    @IBAction func btnBackClicked(_ sender: Any) {
        self.dismiss(animated: false)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
       textField.resignFirstResponder()
       return true
    }
    
    @IBAction func btnSignUpClicked(_ sender: Any) {
        let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeWhichOneViewController")
        controller.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(controller, animated: true, completion: nil)
        
        
    }
    //MARK: Show Date Picker

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
